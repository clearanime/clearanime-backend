/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_aniss_free(a: number): void;
export function aniss_new(a: number): number;
export function aniss_resizeTextures(a: number): void;
export function aniss_setScale(a: number, b: number, c: number): void;
export function aniss_setSource(a: number, b: number): void;
export function aniss_addProgram(a: number, b: number, c: number): number;
export function aniss_render(a: number): number;
export function __wbg_programwrapper_free(a: number): void;
export function __wbg_program_free(a: number): void;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export function __wbindgen_free(a: number, b: number): void;
export function __wbindgen_exn_store(a: number): void;
