import * as wasm from "./index_bg.wasm";
export * from "./index_bg.js";